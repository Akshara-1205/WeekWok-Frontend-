/* Inventory engine: pure functions, no DOM, no writes to state (so they can be unit-tested).
   Meals are processed in calendar order against a running copy of the pantry.
   Deficit = max(0, requirement - current stock). Stock is only committed when a meal is cooked. */
function compute(state = S) {
  const run = {}, def = {}, short = {};
  ING.forEach(i => { run[i.id] = state.p[i.id].stock; def[i.id] = 0; });

  for (let d = 0; d < 7; d++) {
    for (let m = 0; m < 3; m++) {
      const k = slotKey(d, m);
      const r = REC[state.plan[k]];
      if (!r) continue;

      for (const [id, q] of Object.entries(r.ing)) {
        if (!(id in run)) continue;
        const take = Math.min(run[id], q);
        run[id] -= take;

        if (q > take) {
          def[id] += q - take;
          short[k] = true;
        }
      }
    }
  }

  return { run, def, short };
}

function cookable(r, state = S) {
  const { run } = compute(state);
  return Object.entries(r.ing).every(([id, q]) => run[id] >= q);
}

function groceryItems(state = S) {
  const { def } = compute(state);
  return ING
    .filter(i => def[i.id] > 0)
    .map(i => ({ ...i, qty: def[i.id], price: cost(i.id, def[i.id]) }));
}

function groupByAisle(items) {
  const g = {};
  AISLES.forEach(a => {
    const l = items.filter(i => i.aisle === a);
    if (l.length) g[a] = l;
  });
  return g;
}