/* UI: rendering and event handling */
function toast(msg, bad) {
  const t = $('#toast');
  t.textContent = msg;
  t.hidden = false;
  t.style.background = bad ? '#8a5a00' : '';
  clearTimeout(toast.t);
  toast.t = setTimeout(() => t.hidden = true, 3500);
}

/* ---------- actions ---------- */
function assign(d, m, rid) {
  const before = compute().def;
  S.plan[slotKey(d, m)] = rid;
  save();

  const after = compute().def;
  const added = ING
    .filter(i => after[i.id] > before[i.id])
    .map(i => fmt(after[i.id] - before[i.id], i.unit) + ' ' + i.name);

  render();
  added.length
    ? toast('🛒 Added to grocery list: ' + added.join(', '))
    : toast('✅ ' + REC[rid].name + ' is fully covered by your pantry');
}

function removeMeal(d, m) {
  delete S.plan[slotKey(d, m)];
  save();
  render();
}

function cookMeal(d, m) {
  const r = REC[S.plan[slotKey(d, m)]];
  if (!r) return;

  for (const [id, q] of Object.entries(r.ing)) {
    S.p[id].stock = Math.max(0, S.p[id].stock - q);
  }

  delete S.plan[slotKey(d, m)];
  save();
  render();
  toast('🍽️ ' + r.name + ' cooked – pantry updated');
}

function adjust(id, dir) {
  const step = I[id].unit === 'pcs' ? 1 : 50;
  S.p[id].stock = Math.max(0, S.p[id].stock + dir * step);
  save();
  render();
}

function bought(id) {
  S.p[id].stock += compute().def[id];
  save();
  render();
  toast('Stocked up on ' + I[id].name);
}

/* ---------- views ---------- */
function renderGrid() {
  const { short } = compute();
  let h = '<div class="gh"></div>' + DAYS.map(d => `<div class="gh">${d}</div>`).join('');

  MEALS.forEach((ml, m) => {
    h += `<div class="gl">${ml}</div>`;

    DAYS.forEach((_, d) => {
      const r = REC[S.plan[slotKey(d, m)]];
      const k = slotKey(d, m);

      h += `<div class="slot" data-d="${d}" data-m="${m}" tabindex="0" aria-label="${DAYS[d]} ${ml}">` +
        (r
          ? `<div class="meal ${short[k] ? 'short' : ''}">${r.emoji} <b>${r.name}</b>
             <small>${r.prep} min${short[k] ? ' · ⚠ missing items' : ''}</small>
             <button class="x" data-act="rm" aria-label="Remove">×</button>
             <button class="done" data-act="cook">Cooked</button>
           </div>`
          : '<span class="add">+ Add meal</span>') +
        '</div>';
    });
  });

  $('#grid').innerHTML = h;
}

function renderRecipeList() {
  $('#rlist').innerHTML = Object.values(REC).map(r =>
    `<div class="rc" draggable="true" data-rid="${r.id}">${r.emoji} <b>${r.name}</b>
      <small>${r.prep} min · serves ${r.serves} ${cookable(r) ? '<span class="tag good">Cook now</span>' : ''}</small>
    </div>`
  ).join('');
}

function renderPantry() {
  const { run } = compute();

  $('#ptable').innerHTML =
    `<div class="tbl"><table>
      <tr><th>Item</th><th>In stock</th><th>After planned meals</th><th>Status</th><th>Adjust</th></tr>` +
    ING.map(i => {
      const p = S.p[i.id];
      const left = p.exp ? daysLeft(p.exp) : null;
      const rem = run[i.id];
      let tags = '';

      if (rem <= i.min) tags += '<span class="tag low">Low stock</span>';
      if (left !== null && left <= 3) {
        tags += `<span class="tag exp">${left <= 0 ? 'Expired / today' : 'Expires in ' + left + 'd'}</span>`;
      }

      return `<tr>
        <td>${i.emoji} ${i.name}</td>
        <td>${fmt(p.stock, i.unit)}</td>
        <td>${fmt(rem, i.unit)}</td>
        <td>${tags || '<span class="tag good">OK</span>'}</td>
        <td>
          <button class="step" data-id="${i.id}" data-dir="-1" aria-label="Decrease ${i.name}">−</button>
          <button class="step" data-id="${i.id}" data-dir="1" aria-label="Increase ${i.name}">+</button>
        </td>
      </tr>`;
    }).join('') +
    '</table></div>';
}

function renderGrocery() {
  const items = groceryItems();
  const total = items.reduce((s, i) => s + i.price, 0);

  $('#gcount').textContent = items.length;
  $('#gcount').hidden = !items.length;

  $('#glist').innerHTML = items.length
    ? Object.entries(groupByAisle(items))
        .map(([a, list]) =>
          `<h3 class="aisle">${a}</h3>` +
          list.map(i =>
            `<div class="item">
              <span>${i.emoji} <b>${i.name}</b> – ${fmt(i.qty, i.unit)}
                <small>(≈ ₹${Math.ceil(i.price)})</small>
              </span>
              <button class="mini" data-bought="${i.id}">Mark bought</button>
            </div>`
          ).join('')
        ).join('') +
        `<div class="total">Estimated weekly cost: ₹${Math.ceil(total)}</div>`
    : '<div class="empty">Nothing to buy. Plan some meals and missing ingredients will show up here.</div>';
}

function renderRecipes() {
  $('#rcat').className = 'cards';
  $('#rcat').innerHTML = Object.values(REC).map(r =>
    `<div class="card">
      <h3>${r.emoji} ${r.name}</h3>
      <div>${r.prep} min · serves ${r.serves} ${cookable(r) ? '<span class="tag good">Cook now</span>' : ''}</div>
      <ul>${Object.entries(r.ing).map(([id, q]) => `<li>${I[id].name}: ${fmt(q, I[id].unit)}</li>`).join('')}</ul>
    </div>`
  ).join('');
}

function renderExpiry() {
  const soon = ING
    .filter(i => S.p[i.id].exp && daysLeft(S.p[i.id].exp) <= 3 && S.p[i.id].stock > 0)
    .map(i => `${i.name} (${daysLeft(S.p[i.id].exp) <= 0 ? 'today' : daysLeft(S.p[i.id].exp) + 'd'})`);

  const b = $('#expiry');
  b.hidden = !soon.length;
  b.textContent = '⏰ Use soon: ' + soon.join(', ');
}

function render() {
  renderGrid();
  renderRecipeList();
  renderPantry();
  renderGrocery();
  renderRecipes();
  renderExpiry();
}

/* ---------- picker modal (tap alternative to drag & drop) ---------- */
function openPick(d, m) {
  $('#mtitle').textContent = `Add to ${DAYS[d]} ${MEALS[m]}`;

  $('#mbody').innerHTML = Object.values(REC).map(r =>
    `<button class="pick" data-rid="${r.id}">
      ${r.emoji} <b>${r.name}</b> · ${r.prep} min
      ${cookable(r) ? '<span class="tag good">Cook now</span>' : ''}<br>
      <small>${Object.entries(r.ing).map(([id, q]) => I[id].name + ' ' + fmt(q, I[id].unit)).join(', ')}</small>
    </button>`
  ).join('');

  $('#modal').hidden = false;
  $('#modal').dataset.d = d;
  $('#modal').dataset.m = m;
}

const closeModal = () => $('#modal').hidden = true;

/* ---------- events ---------- */
$('#tabs').onclick = e => {
  const t = e.target.closest('[data-tab]');
  if (!t) return;

  document.querySelectorAll('nav button').forEach(b => b.classList.toggle('on', b === t));
  document.querySelectorAll('.tab').forEach(s => s.classList.toggle('on', s.id === t.dataset.tab));
};

$('#grid').onclick = e => {
  const slot = e.target.closest('.slot');
  if (!slot) return;

  const d = +slot.dataset.d;
  const m = +slot.dataset.m;
  const act = e.target.dataset.act;

  if (act === 'rm') return removeMeal(d, m);
  if (act === 'cook') return cookMeal(d, m);
  openPick(d, m);
};

$('#grid').onkeydown = e => {
  if (e.key === 'Enter' && e.target.classList.contains('slot')) e.target.click();
};

$('#rlist').ondragstart = e => {
  const c = e.target.closest('.rc');
  if (c) e.dataTransfer.setData('text/plain', c.dataset.rid);
};

$('#grid').ondragover = e => {
  const s = e.target.closest('.slot');
  if (s) {
    e.preventDefault();
    s.classList.add('over');
  }
};

$('#grid').ondragleave = e => {
  const s = e.target.closest('.slot');
  if (s) s.classList.remove('over');
};

$('#grid').ondrop = e => {
  const s = e.target.closest('.slot');
  if (!s) return;

  e.preventDefault();
  s.classList.remove('over');

  const rid = e.dataTransfer.getData('text/plain');
  if (REC[rid]) assign(+s.dataset.d, +s.dataset.m, rid);
};

$('#mbody').onclick = e => {
  const b = e.target.closest('[data-rid]');
  if (!b) return;

  const { d, m } = $('#modal').dataset;
  closeModal();
  assign(+d, +m, b.dataset.rid);
};

$('#mclose').onclick = closeModal;
$('#modal').onclick = e => {
  if (e.target.id === 'modal') closeModal();
};
document.onkeydown = e => {
  if (e.key === 'Escape') closeModal();
};

$('#ptable').onclick = e => {
  const b = e.target.closest('.step');
  if (b) adjust(b.dataset.id, +b.dataset.dir);
};

$('#glist').onclick = e => {
  const b = e.target.closest('[data-bought]');
  if (b) bought(b.dataset.bought);
};

function waText() {
  const items = groceryItems();
  const head = '🛒 *WeekWok Grocery List*\n';

  if (!items.length) return head + '\n✅ Nothing to buy this week!';

  return head +
    Object.entries(groupByAisle(items))
      .map(([a, l]) =>
        `\n*${a}*\n` + l.map(i => `${i.emoji} ${i.name} – ${fmt(i.qty, i.unit)}`).join('\n')
      ).join('\n') +
    `\n\n💰 Est. total: ₹${Math.ceil(items.reduce((s, i) => s + i.price, 0))}`;
}

$('#copyWa').onclick = () =>
  navigator.clipboard.writeText(waText()).then(
    () => toast('Copied – paste it into WhatsApp'),
    () => toast('Copy failed. Use Share instead.', true)
  );

$('#shareWa').onclick = () =>
  window.open('https://wa.me/?text=' + encodeURIComponent(waText()), '_blank');

$('#reset').onclick = () => {
  if (confirm('Reset pantry, meal plan and custom items to demo data?')) {
    try {
      localStorage.removeItem('weekwok');
    } catch (e) {}
    location.reload();
  }
};

/* ---------- add item / add recipe forms ---------- */
function openIngForm() {
  $('#mtitle').textContent = 'Add pantry item';
  $('#mbody').innerHTML = `<form id="f-ing" novalidate>
    <label>Name<input name="name" maxlength="30" required></label>
    <label>Unit<select name="unit">
      <option value="g">grams (g)</option>
      <option value="ml">millilitres (ml)</option>
      <option value="pcs">pieces</option>
    </select></label>
    <label>In stock (in that unit)<input name="stock" type="number" min="0" step="any" value="0"></label>
    <label>Low-stock warning below<input name="min" type="number" min="0" step="any" value="0"></label>
    <label>Price (₹ per 100 g/ml, or per piece)<input name="price" type="number" min="0" step="any" value="0"></label>
    <label>Aisle<select name="aisle">${AISLES.map(a => `<option>${a}</option>`).join('')}</select></label>
    <label>Expiry date (optional)<input name="expDate" type="date"></label>
    <p class="err" role="alert"></p>
    <button class="primary">Add item</button>
  </form>`;
  $('#modal').hidden = false;
}

function openRecForm() {
  $('#mtitle').textContent = 'Add family recipe';
  $('#mbody').innerHTML = `<form id="f-rec" novalidate>
    <label>Recipe name<input name="name" maxlength="30" required></label>
    <label>Prep time (minutes)<input name="prep" type="number" min="1" max="600" step="1" value="30"></label>
    <label>Serves<input name="serves" type="number" min="1" max="50" step="1" value="4"></label>
    <label>Ingredients (one per line, e.g. "Paneer 400g")
      <textarea name="ingText" rows="5" placeholder="Paneer 400g&#10;Onions 100g&#10;Eggs 4"></textarea>
    </label>
    <p class="err" role="alert"></p>
    <button class="primary">Add recipe</button>
  </form>`;
  $('#modal').hidden = false;
}

document.addEventListener('submit', e => {
  const f = e.target;
  const v = Object.fromEntries(new FormData(f));
  const err = f.querySelector('.err');

  e.preventDefault();

  if (f.id === 'f-ing') {
    const r = validateIngredient(v);
    if (!r.ok) {
      err.textContent = r.errors.join(' ');
      return;
    }

    S.custom.ings.push(r.value);
    registerIng(r.value);
    toast('Added ' + r.value.name);
  } else if (f.id === 'f-rec') {
    const r = validateRecipe(v);
    if (!r.ok) {
      err.textContent = r.errors.join(' ');
      return;
    }

    S.custom.recs.push(r.value);
    registerRec(r.value);
    toast('Added ' + r.value.name);
  } else {
    return;
  }

  save();
  closeModal();
  render();
});

$('#addIng').onclick = openIngForm;
$('#addRec').onclick = openRecForm;

registerAll();
render();